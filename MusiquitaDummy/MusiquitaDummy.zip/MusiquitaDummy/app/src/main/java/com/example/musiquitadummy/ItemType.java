package com.example.musiquitadummy;

public enum ItemType {
    YOUTUBE_MEDIA_NONE,
    YOUTUBE_MEDIA_TYPE_VIDEO,
    YOUTUBE_MEDIA_TYPE_PLAYLIST
}
